const moment = require("moment");
const config = require("./config");
const mongoose = require("mongoose");

//model
const { offlineUser } = require("./server/user/user.controller");
const Wallet = require("./server/wallet/wallet.model");
const User = require("./server/user/user.model");
const Follower = require("./server/follower/follower.model");
const LiveUser = require("./server/liveUser/liveUser.model");
const Chat = require("./server/chat/chat.model");
const ChatTopic = require("./server/chatTopic/chatTopic.model");
const LiveStreamingHistory = require("./server/liveStreamingHistory/liveStreamingHistory.model");

//FCM node
var FCM = require("fcm-node");
var fcm = new FCM(config.SERVER_KEY);

//socket io
io.on("connect", (socket) => {
  console.log("Connection done");

  const { globalRoom } = socket.handshake.query;
  console.log("socket.handshake.query ==== : ", socket.handshake.query);
  console.log("globalRoom connected: ", globalRoom);

  const id = globalRoom && globalRoom.split(":")[1];
  console.log("id: ", id);

  socket.join(globalRoom);

  //live-streaming
  socket.on("liveRoomConnect", async (data) => {
    console.log("liveRoomConnect  connected:   ", data);
    socket.join(data?.liveStreamingId);
    io.in(data?.liveStreamingId).emit("liveRoomConnect", data);
  });

  socket.on("liveReJoin", async (data) => {
    console.log("liveReJoin  listen:   ", data);
    let liveUserModel;
    socket.join(data?.liveStreamingId);

    if (data.isLive) {
      liveUserModel = await LiveUser.findOne({ liveUserId: data?.userId });
      if (!liveUserModel) {
        io.in(data.liveStreamingId).emit("liveReJoin", false);
        return;
      }
    }

    io.in(data?.liveStreamingId).emit("liveReJoin", true);
  });

  socket.on("comment", async (data) => {
    console.log("comment data:  ", data);

    const dataOfComment = JSON.parse(data);
    socket.join(dataOfComment?.liveStreamingId);

    await LiveStreamingHistory.updateOne(
      { _id: dataOfComment?.liveStreamingId },
      { $inc: { comments: 1 } }
    );

    io.in(dataOfComment?.liveStreamingId).emit("comment", data);
  });

  socket.on("liveUserGift", async (data) => {
    console.log("liveUserGift data:  ", data);

    const sockets = await io
      .in("globalRoom:" + data.senderUserId)
      .fetchSockets();
    sockets?.length
      ? sockets[0].join(data.liveStreamingId)
      : console.log("sockets not able to emit in liveUserGift");

    const user = await User.findById(data.senderUserId).populate("level");

    if (user && data.coin <= user.diamond) {
      user.diamond -= data.coin;
      user.spentCoin += data.coin;
      user.rCoin += data.coin;
      await user.save();
      const walletHistory = [
        {
          userId: user._id,
          diamond: data.coin,
          type: 0,
          isIncome: false,
          date: new Date().toLocaleString("en-US", {
            timeZone: "Asia/Kolkata",
          }),
        },
        {
          userId: user._id,
          rCoin: data.coin,
          type: 0,
          isIncome: true,
          date: new Date().toLocaleString("en-US", {
            timeZone: "Asia/Kolkata",
          }),
        },
      ];
      await Wallet.insertMany(walletHistory);

      await LiveUser.updateOne(
        { liveUserId: user?._id },
        { $inc: { rCoin: data?.coin } }
      );

      io.in(data.liveStreamingId).emit("gift", data, user, user);
    }
  });

  //normal user send gift during live streaming
  socket.on("normalUserGift", async (data) => {
    console.log("normalUser GIFT ======================================", data);
    const [senderUser, receiverUser] = await Promise.all([
      User.findById(data.senderUserId).populate("level"),
      User.findById(data.receiverUserId).populate("level"),
    ]);
    console.log("senderUser", senderUser?.name);
    console.log("receiverUser", receiverUser?.name);

    if (senderUser && receiverUser && data?.coin <= senderUser?.diamond) {
      senderUser.diamond -= data?.coin;
      senderUser.spentCoin += data?.coin;
      await senderUser.save();

      receiverUser.rCoin += data?.coin;
      await receiverUser.save();

      const walletHistory = [
        {
          userId: senderUser._id,
          otherUserId: receiverUser._id,
          diamond: data.coin,
          type: 0,
          isIncome: false,
          date: new Date().toLocaleString("en-US", {
            timeZone: "Asia/Kolkata",
          }),
        },
        {
          userId: receiverUser._id,
          otherUserId: senderUser._id,
          rCoin: data.coin,
          type: 0,
          isIncome: true,
          date: new Date().toLocaleString("en-US", {
            timeZone: "Asia/Kolkata",
          }),
        },
      ];
      await Wallet.insertMany(walletHistory);

      await LiveUser.updateOne(
        { liveUserId: receiverUser._id },
        { $inc: { rCoin: data?.coin } }
      );

      await LiveStreamingHistory.updateOne(
        { _id: data.liveStreamingId },
        {
          $inc: { rCoin: data?.coin, gifts: 1 },
          $set: {
            endTime: new Date().toLocaleString("en-US", {
              timeZone: "Asia/Kolkata",
            }),
          },
        }
      );

      io.in(data?.liveStreamingId).emit("gift", data, senderUser, receiverUser);
    } else {
      await LiveStreamingHistory.updateOne(
        { _id: data?.liveStreamingId },
        {
          endTime: new Date().toLocaleString("en-US", {
            timeZone: "Asia/Kolkata",
          }),
        }
      );
    }
  });

  socket.on("addView", async (data) => {
    console.log("data in addView: ", data);
    const [liveStreamingHistory, liveUser, joinedUserExist] = await Promise.all(
      [
        LiveStreamingHistory.findById(data?.liveStreamingId),
        LiveUser.findById(data?.liveUserMongoId),
        LiveUser.findOne({
          _id: data?.liveUserMongoId,
          "view.userId": data?.userId,
        }),
      ]
    );
    socket.join(data?.liveStreamingId);

    if (liveUser) {
      if (joinedUserExist) {
        await LiveUser.updateOne(
          { _id: liveUser._id, "view.userId": data.userId },
          {
            $set: {
              "view.$.userId": data?.userId,
              "view.$.image": data?.image,
              "view.$.name": data?.name,
              "view.$.gender": data?.gender,
              "view.$.country": data?.country,
              "view.$.isVIP": data?.isVIP,
              "view.$.isAdd": true,
            },
          }
        );
      } else {
        liveUser.view.push({
          userId: data?.userId,
          image: data?.image,
          country: data?.country,
          gender: data?.gender,
          name: data?.name,
          isVIP: data?.isVIP,
          isAdd: true,
        });

        await liveUser.save();
      }
    }

    const dataOfLiveUser = await LiveUser.findById(data.liveUserMongoId);

    if (liveStreamingHistory && dataOfLiveUser) {
      liveStreamingHistory.user = dataOfLiveUser.view.length;
      liveStreamingHistory.endTime = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
      });
      liveStreamingHistory.momentEndTime = moment(new Date()).format(
        "HH:mm:ss"
      );
      await liveStreamingHistory.save();
      console.log("ADD VIEW");

      io.in(data?.liveStreamingId).emit("view", dataOfLiveUser.view);
      io.in(data?.liveStreamingId).emit(
        "seat",
        { ...dataOfLiveUser._doc, view: dataOfLiveUser.view.length || 0 },
        null
      );
    }
  });

  socket.on("lessView", async (data) => {
    console.log("lessView data: ", data);
    const [liveStreamingHistory] = await Promise.all([
      LiveStreamingHistory.findById(data?.liveStreamingId),
      LiveUser.updateOne(
        { _id: data?.liveUserMongoId, "view.userId": data?.userId },
        {
          $set: {
            "view.$.isAdd": false,
          },
        }
      ),
    ]);

    const socket1 = await io.in("globalRoom:" + data?.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data?.liveStreamingId)
      : console.log("socket1 not able to join in lessView");

    const liveUser = await LiveUser.findOne({
      _id: data?.liveUserMongoId,
      "view.isAdd": true,
    });

    if (liveStreamingHistory) {
      liveStreamingHistory.endTime = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
      });
      liveStreamingHistory.momentEndTime = moment(new Date()).format(
        "HH:mm:ss"
      );
      await liveStreamingHistory.save();
    }

    const dataOfLiveUser = await LiveUser.aggregate([
      {
        $match: { _id: liveUser?._id },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);

    await io
      .in(data?.liveStreamingId)
      .emit("view", liveUser ? liveUser.view : []);
    await io.in(data?.liveStreamingId).emit("seat", dataOfLiveUser[0], null);
    socket.leave(data?.liveStreamingId);
  });

  socket.on("liveHostEnd", async (data) => {
    console.log(
      "LiveHostEnd listen ==============================================",
      data
    );
    const [liveStreamingHistory] = await Promise.all([
      LiveStreamingHistory.findById(data?.liveStreamingId),
      LiveUser.deleteOne({
        liveUserId: data?.liveUserId,
        liveStreamingId: data?.liveStreamingId,
      }),
    ]);

    if (liveStreamingHistory) {
      console.log("liveStreamingHistory in liveHostEnd:   ");

      liveStreamingHistory.momentEndTime = moment(new Date()).format(
        "HH:mm:ss"
      );
      liveStreamingHistory.endTime = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
      });
      liveStreamingHistory.duration = moment
        .utc(
          moment(new Date(liveStreamingHistory.endTime)).diff(
            moment(new Date(liveStreamingHistory.startTime))
          )
        )
        .format("HH:mm:ss");
      await liveStreamingHistory.save();

      console.log("liveStreamingHistory Updated in liveHostEnd:   ");
    }

    io.in(data?.liveStreamingId).emit("liveHostEnd", "end");
    const abc = io.sockets.adapter.rooms.get(data?.liveStreamingId);
    console.log("liveHostEnd before leave EMIT sockets : ====== ", abc);
    io.socketsLeave(data?.liveStreamingId);
  });

  //audio-room
  socket.on("addRequested", async (data_) => {
    console.log("addRequested data: ", data_);

    const data = JSON.parse(data_);
    console.log("parsed addRequested data: ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in addRequested");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in addRequested ==================: ", xyz);

    const [liveUser, joinedUserExist] = await Promise.all([
      LiveUser.findById(data.liveUserMongoId),
      LiveUser.findOne({
        _id: data.liveUserMongoId,
        "seat.userId": data.userId,
        "seat.position": { $ne: data.position },
      }),
    ]);

    if (liveUser) {
      if (joinedUserExist) {
        console.log("joinedUserExist in addRequested: ", joinedUserExist);

        await LiveUser.findOneAndUpdate(
          { _id: liveUser._id, "seat.userId": data.userId },
          {
            $set: {
              "seat.$.userId": null,
              "seat.$.image": null,
              "seat.$.name": null,
              "seat.$.country": null,
              "seat.$.agoraUid": null,
              "seat.$.mute": false,
              "seat.$.lock": false,
              "seat.$.reserved": false,
              "seat.$.invite": false,
            },
          }
        ).lean();
      }

      await LiveUser.findOneAndUpdate(
        { _id: liveUser._id, "seat.position": data.position },
        {
          $set: {
            "seat.$.userId": data.userId,
            "seat.$.image": null,
            "seat.$.name": null,
            "seat.$.country": null,
            "seat.$.agoraUid": null,
            "seat.$.mute": false,
            "seat.$.lock": true,
            "seat.$.reserved": false,
            "seat.$.invite": true,
          },
        }
      ).lean();

      const liveUser_ = await LiveUser.aggregate([
        {
          $match: { _id: liveUser._id },
        },
        { $addFields: { view: { $size: "$view" } } },
      ]);

      console.log("liveUser emitted in addRequested: ", liveUser_[0]?._id);

      io.in(data.liveStreamingId).emit("seat", liveUser_[0], null);
      io.in(data.liveStreamingId).emit(
        "invite",
        liveUser_[0].seat[data.position]
      );
    }
  });

  socket.on("addParticipants", async (data_) => {
    console.log("data in addParticipants:  ", data_);

    const data = JSON.parse(data_);
    console.log("parsed data in addParticipants:  ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in addParticipants");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in addParticipants ==================: ", xyz);

    const [liveUser, joinedUserExist] = await Promise.all([
      LiveUser.findById(data.liveUserMongoId),
      LiveUser.findOne({
        _id: data.liveUserMongoId,
        seat: {
          $elemMatch: { userId: data.userId, position: { $ne: data.position } },
        },
      }),
    ]);

    if (liveUser) {
      console.log("joinExist in add participants:  ", joinedUserExist);

      if (joinedUserExist) {
        console.log("joinExist in add participants:  ");

        await LiveUser.findOneAndUpdate(
          {
            _id: liveUser._id,
            "seat.userId": new mongoose.Types.ObjectId(data.userId),
          },
          {
            $set: {
              "seat.$.userId": null,
              "seat.$.image": null,
              "seat.$.name": null,
              "seat.$.country": null,
              "seat.$.agoraUid": null,
              "seat.$.mute": false,
              "seat.$.lock": false,
              "seat.$.reserved": false,
              "seat.$.invite": false,
            },
          },
          {
            new: true,
          }
        ).lean();

        await LiveUser.findOneAndUpdate(
          { _id: liveUser._id, "seat.position": data.position },
          {
            $set: {
              "seat.$.userId": data.userId,
              "seat.$.image": data.image,
              "seat.$.name": data.name,
              "seat.$.country": data.country,
              "seat.$.agoraUid": data.agoraUid,
              "seat.$.mute": false,
              "seat.$.lock": false,
              "seat.$.reserved": true,
              "seat.$.invite": false,
            },
          }
        ).lean();

        const _liveUser = await LiveUser.aggregate([
          {
            $match: { _id: liveUser._id },
          },
          { $addFields: { view: { $size: "$view" } } },
        ]);

        console.log(
          "socket data in addParticipants after........",
          _liveUser[0]
        );

        io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
      } else {
        console.log("else add participants:  ");

        await LiveUser.findOneAndUpdate(
          { _id: liveUser._id, "seat.position": data.position },
          {
            $set: {
              "seat.$.userId": data.userId,
              "seat.$.image": data.image,
              "seat.$.name": data.name,
              "seat.$.country": data.country,
              "seat.$.agoraUid": data.agoraUid,
              "seat.$.mute": false,
              "seat.$.lock": false,
              "seat.$.reserved": true,
              "seat.$.invite": false,
            },
          }
        ).lean();

        const _liveUser = await LiveUser.aggregate([
          {
            $match: { _id: liveUser._id },
          },
          { $addFields: { view: { $size: "$view" } } },
        ]);

        console.log(
          "socket data in addParticipants after........ else",
          _liveUser[0]?._id
        );

        io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
      }
    }
  });

  socket.on("lessParticipants", async (data_) => {
    console.log("data in lessParticipants:   ", data_);

    const data = JSON.parse(data_);
    console.log("parsed data in lessParticipants:   ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in lessParticipants");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log(
      "adapter sockets in lessParticipants ==================: ",
      xyz
    );

    if (data.position !== -1) {
      await LiveUser.findOneAndUpdate(
        {
          _id: new mongoose.Types.ObjectId(data.liveUserMongoId),
          "seat.position": data.position,
        },
        {
          $set: {
            "seat.$.userId": null,
            "seat.$.image": null,
            "seat.$.name": null,
            "seat.$.country": null,
            "seat.$.agoraUid": null,
            "seat.$.mute": false,
            "seat.$.lock": false,
            "seat.$.reserved": false,
            "seat.$.invite": false,
          },
        },
        {
          new: true,
        }
      );
    }

    const _liveUser = await LiveUser.aggregate([
      {
        $match: { _id: new mongoose.Types.ObjectId(data.liveUserMongoId) },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);
    if (_liveUser?.length > 0) {
      io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
      io.in("globalRoom:" + data?.removedUserID).emit(
        "lessParticipants",
        _liveUser[0],
        null
      );
    }
  });

  socket.on("muteSeat", async (data_) => {
    console.log("data in muteSeat:   ", data_);

    const data = JSON.parse(data_);
    console.log("parsed data in muteSeat:   ", data);
    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in muteSeat ==================: ", xyz);

    await LiveUser.updateOne(
      {
        _id: new mongoose.Types.ObjectId(data.liveUserMongoId),
        "seat.position": data.position,
      },
      {
        $set: {
          "seat.$.mute": data.mute,
        },
      }
    );

    const _liveUser = await LiveUser.aggregate([
      {
        $match: { _id: new mongoose.Types.ObjectId(data.liveUserMongoId) },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);
    if (data.agoraId) {
      console.log("data.agoraId :", data.agoraId);
      io.in(data.liveStreamingId).emit("seat", _liveUser[0], {
        agoraId: data.agoraId,
        mute: data.mute,
      });
    } else {
      io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
    }
    io.in("globalRoom:" + data.mutedUserId).emit("muteSeat", {
      agoraId: data.agoraId,
      mute: data.mute,
    });
  });

  socket.on("lockSeat", async (data_) => {
    console.log("data in lockSeat:   ", data_);

    const data = JSON.parse(data_);
    console.log("parsed data in lockSeat:   ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in lockSeat");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in lockSeat ==================: ", xyz);

    await LiveUser.updateOne(
      {
        _id: new mongoose.Types.ObjectId(data.liveUserMongoId),
        "seat.position": data.position,
      },
      {
        $set: {
          "seat.$.lock": data.lock,
        },
      }
    );

    const _liveUser = await LiveUser.aggregate([
      {
        $match: { _id: new mongoose.Types.ObjectId(data.liveUserMongoId) },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);

    io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
  });

  socket.on("changeTheme", async (data) => {
    console.log("changeTheme data:  ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in changeTheme");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in changeTheme ==================: ", xyz);

    const liveUser = await LiveUser.findById(data.liveUserMongoId);
    if (liveUser) {
      liveUser.background = data.background;
      await liveUser.save();

      io.in(data.liveStreamingId).emit("changeTheme", {
        background: data.background,
      });
    }
  });
  //misc
  socket.on("allSeatLock", async (data) => {
    console.log("data in allSeatLock:   ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in allSeatLock");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in allSeatLock ==================: ", xyz);

    await LiveUser.updateOne(
      {
        _id: mongoose.Types.ObjectId(data.liveUserMongoId),
      },
      {
        $set: {
          "seat.$.lock": data.lock,
        },
      }
    );

    const _liveUser = await LiveUser.aggregate([
      {
        $match: { _id: mongoose.Types.ObjectId(data.liveUserMongoId) },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);

    io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
  });

  socket.on("blockedList", async (data) => {
    console.log("blockedList data:  ", data);
    io.in(data.liveStreamingId).emit("blockedList", data);
  });

  socket.on("speaking", async (data_) => {
    console.log("data in speaking: ", data_); //liveUserMongoId,agoraUid.isspeaking,liveStreamingId,userId

    const data = JSON.parse(data_);
    console.log("parsed data in speaking: ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in speaking");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in speaking ==================: ", xyz);

    await LiveUser.updateOne(
      {
        _id: new mongoose.Types.ObjectId(data.liveUserMongoId),
        "seat.agoraUid": data.agoraUID,
      },
      {
        $set: {
          "seat.$.isSpeaking": data.isSpeaking,
        },
      }
    );

    const _liveUser = await LiveUser.aggregate([
      {
        $match: { _id: new mongoose.Types.ObjectId(data.liveUserMongoId) },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);

    io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
  });

  socket.on("declineInvite", async (data) => {
    console.log("data in declineInvite:   ", data);

    const socket1 = await io.in("globalRoom:" + data.userId).fetchSockets();
    socket1?.length
      ? socket1[0].join(data.liveStreamingId)
      : console.log("socket1 not able to join in declineInvite");

    const xyz = io.sockets.adapter.rooms.get(data.liveStreamingId);
    console.log("adapter sockets in declineInvite ==================: ", xyz);

    await LiveUser.updateOne(
      { _id: data.liveUserMongoId, "seat.position": data.position },
      {
        $set: {
          "seat.$.userId": null,
          "seat.$.image": null,
          "seat.$.name": null,
          "seat.$.country": null,
          "seat.$.agoraUid": null,
          "seat.$.mute": false,
          "seat.$.lock": false,
          "seat.$.reserved": false,
          "seat.$.invite": false,
        },
      }
    );

    const _liveUser = await LiveUser.aggregate([
      {
        $match: { _id: mongoose.Types.ObjectId(data.liveUserMongoId) },
      },
      { $addFields: { view: { $size: "$view" } } },
    ]);

    io.in(data.liveStreamingId).emit("seat", _liveUser[0], null);
  });

  //misc
  socket.on("liveStreaming", (data) => {
    console.log("liveStreaming", data);
    console.log("LiveRoom liveStreaming ", liveRoom);

    io.in(liveRoom).emit("liveStreaming", data);
  });

  socket.on("simpleFilter", (data) => {
    console.log("simpleFilter", data);
    console.log("LiveRoom simpleFilter ", data?.liveStreamingId);
    io.in(data?.liveStreamingId).emit("simpleFilter", data);
  });

  socket.on("animatedFilter", (data) => {
    console.log("animatedFilter", data);
    console.log("LiveRoom animatedFilter ", data?.liveStreamingId);
    io.in(data?.liveStreamingId).emit("animatedFilter", data);
  });

  socket.on("gif", (data) => {
    console.log("gif", data);
    console.log("LiveRoom gif ", data?.liveStreamingId);
    io.in(data?.liveStreamingId).emit("gif", data);
  });

  socket.on("getUserProfile", async (data) => {
    console.log("getUserProfile data:  ", data);
    const [user, follower] = await Promise.all([
      User.findById(data?.toUserId)
        .populate("level")
        .select(
          "name username uniqueId gender age image country bio followers following video post level isVIP"
        ),
      Follower.findOne({
        fromUserId: data?.fromUserId,
        toUserId: data?.toUserId,
      }),
    ]);
    if (user) {
      const userData = {
        ...user._doc,
        userId: user._id,
        isFollow: follower ? true : false,
      };

      io.in("globalRoom:" + data?.fromUserId.toString()).emit("data", userData);
    }
  });

  //chat
  socket.on("chat", async (data) => {
    console.log("data in chat:  ", data);

    const chatTopic = await ChatTopic.findById(data?.topic).populate(
      "receiverUser senderUser"
    );
    if (data.messageType === "message") {
      let senderUserIdRoom = "globalRoom:" + chatTopic?.senderUser?._id;
      let receiverIdRoom = "globalRoom:" + chatTopic?.receiverUser?._id;

      if (chatTopic) {
        const chat = new Chat();

        chat.senderId = data?.senderId;
        chat.messageType = "message";
        chat.message = data?.message;
        chat.image = null;
        chat.topic = chatTopic._id;
        chat.date = new Date().toLocaleString("en-US", {
          timeZone: "Asia/Kolkata",
        });
        await chat.save();

        chatTopic.chat = chat._id;
        await chatTopic.save();
        io.in(senderUserIdRoom).emit("chat", data);
        io.in(receiverIdRoom).emit("chat", data);
        let receiverUser, senderUser;
        if (
          chatTopic.senderUser &&
          chatTopic.senderUser._id.toString() === data.senderId.toString()
        ) {
          receiverUser = chatTopic.receiverUser;
          senderUser = chatTopic.senderUser;
        } else if (chatTopic.receiverUser && chatTopic.receiverUser._id) {
          receiverUser = chatTopic.senderUser;
          senderUser = chatTopic.receiverUser;
        }

        if (
          receiverUser &&
          !receiverUser.isBlock &&
          receiverUser.notification.message
        ) {
          const payload = {
            to: receiverUser.fcmToken,
            notification: {
              body: chat.message,
              title: senderUser.name,
            },
            data: {
              data: {
                topic: chatTopic._id,
                message: chat.message,
                date: chat.date,
                chatDate: chat.date,
                userId: senderUser._id,
                name: senderUser.name,
                username: senderUser.username,
                image: senderUser.image,
                country: senderUser.country,
                isVIP: senderUser.isVIP,
                time: "Just Now",
              },
              type: "MESSAGE",
            },
          };

          await fcm.send(payload, function (err, response) {
            if (err) {
              console.log("Something has gone wrong: ", err);
            } else {
              console.log("Successfully sent with response: ", response);
            }
          });
        }
      }
    } else {
      io.in("globalRoom:" + data?.senderId).emit("chat", data);
      io.in("globalRoom:" + chatTopic?.receiverUser._id.toString()).emit(
        "chat",
        data
      );
    }
  });

  //call
  socket.on("callRequest", async (data) => {
    console.log("callRequest data: ", data);

    io.in("globalRoom:" + data.userId1).emit("callRequest", data); // userId1 = receiver user , userId2 = caller user
  });

  socket.on("callConfirmed", async (data) => {
    console.log("callConfirmed data: ", data);
    io.in("globalRoom:" + data.userId2).emit("callConfirmed", data); // userId1 = receiver user , userId2 = caller user
  });

  socket.on("callAnswer", async (data) => {
    console.log("callAnswer data: ", data);

    if (data.isAccept) {
      const socket1 = await io.in("globalRoom:" + data?.userId1).fetchSockets();
      socket1?.length && socket1[0].join(data?.callRoomId);

      const socket2 = await io.in("globalRoom:" + data?.userId2).fetchSockets();
      socket2?.length && socket2[0].join(data?.callRoomId);
    } else {
      await User.updateMany(
        { callId: data?.callRoomId },
        { $set: { callId: "" } }
      );
    }
    io.in("globalRoom:" + data.userId2).emit("callAnswer", data); // userId1 = receiver user , userId2 = caller user
  });

  socket.on("callReceive", async (data) => {
    console.log("callReceive data: ", data);

    let callDetail = await Wallet.findById(data?.callRoomId);
    if (!callDetail) {
      callDetail = await Wallet.findById(data?.callId);
    }

    if (callDetail) {
      const user = await User.findById(callDetail.userId).populate("level");

      if (user && user.diamond >= data.coin) {
        user.diamond -= data.coin;
        user.spentCoin += data.coin;
        await user.save();

        await User.updateOne(
          { _id: callDetail.otherUserId },
          { $inc: { diamond: data.coin } }
        );

        callDetail.diamond += data.coin;
        callDetail.otherUserDiamond += data.coin;
        callDetail.callConnect = true;
        callDetail.callStartTime = new Date().toLocaleString("en-US", {
          timeZone: "Asia/Kolkata",
        });
        callDetail.callEndTime = new Date().toLocaleString("en-US", {
          timeZone: "Asia/Kolkata",
        });
        await callDetail.save();

        io.in(data?.callRoomId).emit("callReceive", user?.name);
      } else {
        io.in(data?.callRoomId).emit("callReceive", null, user);
      }
    }
  });

  //when user decline the call
  socket.on("callCancel", async (data) => {
    console.log("call Cancelled data: ", data);

    const user1 = await User.findById(data?.userId1);
    if (user1) {
      user1.callId = "";
      await user1.save();
    }
    const user2 = await User.findById(data?.userId2);
    if (user2) {
      user2.callId = "";
      await user2.save();
    }
    io.in("globalRoom:" + data.userId1).emit("callCancel", data); // userId1 = receiver user , userId2 = caller user
  });

  socket.on("callDisconnect", async (callId) => {
    console.log("Call disconnect: ", callId);

    await User.updateMany({ callId: callId }, { $set: { callId: "" } });

    const callHistory = await Wallet.findById(callId);
    if (callHistory) {
      callHistory.callEndTime = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
      });
      await callHistory.save();
    }
  });

  socket.on("disconnect", async () => {
    console.log("One of sockets disconnected from our server.", globalRoom);

    if (globalRoom) {
      const socket1 = await io.in(globalRoom).fetchSockets();
      if (socket1?.length == 0) {
        console.log(
          "socket1?.length in Final disconnect:    ",
          socket1?.length
        );

        const liveUser = await LiveUser.findOne({ liveUserId: id });

        if (liveUser) {
          io.in(liveUser?.liveStreamingId.toString()).emit(
            "liveHostEnd",
            "end"
          );
          io.socketsLeave(liveUser.liveStreamingId);

          //@todo : liveEndTime
          const liveStreamingHistory = await LiveStreamingHistory.findById(
            liveUser?.liveStreamingId
          );
          if (liveStreamingHistory) {
            console.log("liveStreamingHistory in liveHostEnd:   ");

            liveStreamingHistory.endTime = new Date().toLocaleString("en-US", {
              timeZone: "Asia/Kolkata",
            });
            liveStreamingHistory.duration = moment
              .utc(
                moment(new Date(liveStreamingHistory.endTime)).diff(
                  moment(new Date(liveStreamingHistory.startTime))
                )
              )
              .format("HH:mm:ss");
            await liveStreamingHistory.save();
            console.log("liveStreamingHistory Updated in liveHostEnd:   ");
          }
          await liveUser.deleteOne();
        }

        const user = await User.findById(id);

        if (user && user.callId) {
          const callHistory = await Wallet.findById(user.callId);
          if (callHistory && callHistory.callEndTime == null) {
            console.log("callHistory in disconnect");

            callHistory.callEndTime = new Date().toLocaleString("en-US", {
              timeZone: "Asia/Kolkata",
            });
            await callHistory.save();
          }
          await User.updateMany(
            { callId: user.callId },
            { $set: { callId: "" } }
          );
        }
        await offlineUser(id);
      }
    }
  });
});
