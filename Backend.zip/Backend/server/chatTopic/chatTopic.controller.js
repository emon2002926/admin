const ChatTopic = require("./chatTopic.model");

const User = require("../user/user.model");
const Setting = require("../setting/setting.model");
const mongoose = require("mongoose");
const dayjs = require("dayjs");
const arrayShuffle = require("shuffle-array");

exports.store = async (req, res) => {
  try {
    if (!req.body.senderUserId || !req.body.receiverUserId)
      return res
        .status(200)
        .json({ status: false, message: "Invalid Details!" });
    const [senderUser, receiverUser, chatTopic] = await Promise.all([
      User.findById(req.body.senderUserId),
      User.findById(req.body.receiverUserId),
      ChatTopic.findOne({
        $or: [
          {
            $and: [
              { senderUser: req.body.senderUserId },
              { receiverUser: req.body.receiverUserId },
            ],
          },
          {
            $and: [
              { receiverUser: req.body.senderUserId },
              { senderUser: req.body.receiverUserId },
            ],
          },
        ],
      }),
    ]);
    if (!senderUser)
      return res
        .status(200)
        .json({ status: false, message: "User does not Exist!" });
    if (!receiverUser)
      return res
        .status(200)
        .json({ status: false, message: "User dose not Exist!" });

    if (chatTopic) {
      return res
        .status(200)
        .json({ status: true, message: "Success!!", chatTopic });
    }

    const newChatTopic = new ChatTopic();
    newChatTopic.senderUser = senderUser._id;
    newChatTopic.receiverUser = receiverUser._id;
    await newChatTopic.save();

    return res
      .status(200)
      .json({ status: true, message: "Success!!", chatTopic: newChatTopic });
  } catch (error) {
    return res.status(500).json({
      status: false,
      error: error.message || "Internal Server Error !",
    });
  }
};

exports.getChatList = async (req, res) => {
  try {
    const start = req.query.start ? parseInt(req.query.start) : 0;
    const limit = req.query.limit ? parseInt(req.query.limit) : 20;

    const [user, list, setting, fakeData] = await Promise.all([
      User.findById(req.query?.userId),
      ChatTopic.aggregate([
        {
          $match: {
            $or: [
              { senderUser: new mongoose.Types.ObjectId(req.query.userId) },
              { receiverUser: new mongoose.Types.ObjectId(req.query.userId) },
            ],
          },
        },
        {
          $unwind: {
            path: "$user",
            preserveNullAndEmptyArrays: false,
          },
        },
        {
          $lookup: {
            from: "chats",
            localField: "chat",
            foreignField: "_id",
            as: "chat",
          },
        },
        {
          $unwind: {
            path: "$chat",
            preserveNullAndEmptyArrays: false,
          },
        },
        {
          $project: {
            _id: 0,
            topic: "$_id",
            message: "$chat.message",
            date: "$chat.date",
            createdAt: "$chat.createdAt",
            userId: "$user._id",
            name: "$user.name",
            username: "$user.username",
            image: "$user.image",
            country: "$user.country",
            isVIP: "$user.isVIP",
            isFake: "$user.isFake",
          },
        },
        {
          $addFields: {
            isFake: false,
          },
        },
        { $sort: { createdAt: -1 } },
      ]),
      Setting.findOne({}),
      User.find({ isFake: true }),
    ]);
    if (!user) {
      return res
        .status(200)
        .json({ status: false, message: "User does not Exist!" });
    }

    const paginatedList = await list?.slice(start, start + limit);

    let now = dayjs();

    const chatList = paginatedList.map((data) => ({
      ...data,
      time:
        now.diff(data.createdAt, "minute") === 0
          ? "Just Now"
          : now.diff(data.createdAt, "minute") <= 60 &&
            now.diff(data.createdAt, "minute") >= 0
          ? now.diff(data.createdAt, "minute") + " minutes ago"
          : now.diff(data.createdAt, "hour") >= 24
          ? dayjs(data.createdAt).format("DD MMM, YYYY")
          : now.diff(data.createdAt, "hour") + " hour ago",
    }));

    if (!setting?.isFake) {
      console.log("real");

      return res.status(200).json({
        status: true,
        message: "Success",
        chatList: chatList,
      });
    } else {
      const fakeUser = await arrayShuffle(fakeData);

      const fakeStart = (await start) - paginatedList.length;
      const fakeLimit = await Math.min(limit, fakeUser.length - fakeStart + 1);

      const fakeChatList = await fakeUser
        .slice(fakeStart, fakeStart + fakeLimit)
        .map((element) => ({
          topic: null,
          message: "hello !",
          date: null,
          chatDate: null,
          userId: element._id,
          name: element.name,
          username: element.username,
          image: element.image,
          country: element.country,
          isVIP: element.isVIP,
          link: element.link,
          time: "Just now",
          isFake: true,
        }));

      return res.status(200).json({
        status: true,
        message: "Success",
        chatList: [...chatList, ...fakeChatList],
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(200).json({
      status: false,
      error: error.message || "Internal Server Error",
    });
  }
};
