const mongoose = require("mongoose");
const seat = require("../../util/defaultSeat");

const liveUserSchema = new mongoose.Schema(
  {
    name: String,
    country: String,
    image: String,
    view: { type: Array, default: [] },
    age: Number,
    token: String,
    channel: String,
    rCoin: Number,
    diamond: Number,
    username: String,
    background: String,
    countryFlagImage: String,
    isVIP: Boolean,
    liveUserId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    agoraUID: { type: Number, default: 0 },
    liveStreamingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "livestreaminghistories",
    },
    isPublic: { type: Boolean, default: true },

    audio: { type: Boolean, default: false },
    seat: {
      type: [
        {
          position: { type: Number },
          mute: { type: Boolean },
          lock: { type: Boolean },
          isSpeaking: { type: Boolean },
          reserved: { type: Boolean },
          invite: { type: Boolean },
          userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
          },
          name: { type: String },
          image: { type: String },
          country: { type: String },
          agoraUid: { type: Number },
        },
      ],
      default: seat.default,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

liveUserSchema.index({ liveUserId: 1 });
liveUserSchema.index({ liveStreamingId: 1 });

module.exports = mongoose.model("LiveUser", liveUserSchema);
