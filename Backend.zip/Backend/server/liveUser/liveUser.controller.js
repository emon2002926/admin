const LiveUser = require("./liveUser.model");
const User = require("../user/user.model");
const Setting = require("../setting/setting.model");
const Follower = require("../follower/follower.model");
const LiveStreamingHistory = require("../liveStreamingHistory/liveStreamingHistory.model");
const { RtcTokenBuilder, RtcRole } = require("agora-access-token");
const seat = require("../../util/defaultSeat");

//FCM node
var FCM = require("fcm-node");
var config = require("../../config");
var fcm = new FCM(config.SERVER_KEY);

//moment
const moment = require("moment");

// Agora token Builder
exports.generateToken = async (req, res) => {
  try {
    if (!req.body.channelName) {
      return res
        .status(200)
        .json({ status: false, message: "Invalid Details !" });
    }

    const setting = await Setting.findOne({});
    if (!setting)
      return res
        .status(200)
        .json({ status: false, message: "Setting Not Found" });

    const role = RtcRole.PUBLISHER;
    const account = "0";
    const expirationTimeInSeconds = 24 * 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

    const token = RtcTokenBuilder.buildTokenWithAccount(
      setting.agoraKey,
      setting.agoraCertificate,
      req.body.channelName,
      account,
      role,
      privilegeExpiredTs
    );

    console.log("Token With UserAccount: " + token);
    return res.status(200).json({ status: true, message: "Success", token });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ status: false, error: error.message || "Server Error" });
  }
};

// live the user
exports.userIsLive = async (req, res) => {
  try {
    if (req.body.userId && req.body.channel) {
      const setting = await Setting.findOne({});
      if (!setting)
        return res
          .status(200)
          .json({ status: false, message: "Setting Not Found" });

      const role = RtcRole.PUBLISHER;
      const uid = req.body.agoraUID ? req.body.agoraUID : 0;
      const expirationTimeInSeconds = 24 * 3600;
      const currentTimestamp = Math.floor(Date.now() / 1000);
      const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

      let [user, token, liveStreamingHistory, liveUser, followers] =
        await Promise.all([
          User.findById(req.body.userId),
          RtcTokenBuilder.buildTokenWithUid(
            setting.agoraKey,
            setting.agoraCertificate,
            req.body.channel,
            uid,
            role,
            privilegeExpiredTs
          ),
          LiveStreamingHistory({
            userId: req.body.userId,
            startTime: new Date().toLocaleString("en-US", {
              timeZone: "Asia/Kolkata",
            }),
            momentStartTime: moment(new Date()).format("HH:mm:ss"),
          }),
          LiveUser.deleteOne({ liveUserId: req.body.userId }),
          Follower.find({
            toUserId: req.body.userId,
          }).populate({
            path: "fromUserId",
            select: "name fcmToken isBlock notification ",
          }),
        ]);

      if (!user) {
        return res
          .status(200)
          .json({ status: false, message: "User does not Exist!" });
      }

      user.isOnline = true;
      user.isBusy = true;
      user.token = token;
      user.channel = req.body.channel;
      await user.save();

      await liveStreamingHistory.save();

      const createLiveUser = new LiveUser();
      createLiveUser.background = req.body.background;
      createLiveUser.audio = req?.body?.audio ? req?.body?.audio : false;
      createLiveUser.isPublic = req.body.isPublic;
      createLiveUser.liveStreamingId = liveStreamingHistory._id;
      createLiveUser.agoraUID = req.body.agoraUID;
      let LiveUserData = await LiveUserFunction(createLiveUser, user);

      LiveUserData.seat[0].userId = user?._id;
      LiveUserData.seat[0].name = user?.name;
      LiveUserData.seat[0].image = user?.image;
      LiveUserData.seat[0].country = user?.country;
      await LiveUserData.save();

      const liveUser_ = await LiveUser.aggregate([
        { $match: { _id: { $eq: createLiveUser._id } } },
        { $addFields: { view: { $size: "$view" } } },
      ]);

      res
        .status(200)
        .json({ status: true, message: "Success", liveUser: liveUser_[0] });

      for (let i = 0; i < followers.length; i += 1000) {
        const filteredFollowers = followers.filter(
          (data) =>
            data.fromUserId &&
            !data.fromUserId.isBlock &&
            data.fromUserId.notification?.favoriteLive
        );
        const batchHosts = filteredFollowers.slice(i, i + 1000);
        const registrationTokens = batchHosts.map(
          (data) => data.fromUserId.fcmToken
        );
        console.log("data?.fromUserId.name  live:     ", user?.name);
        const payload = {
          registration_ids: registrationTokens,
          notification: {
            title: `${user?.name} is Live`,
          },
          data: {
            data: {
              _id: LiveUserData._id,
              liveUserId: LiveUserData.liveUserId,
              name: LiveUserData.name,
              country: LiveUserData.country,
              image: LiveUserData.image,
              token: LiveUserData.token,
              background: LiveUserData.background,
              seat: LiveUserData.seat,
              channel: LiveUserData.channel,
              rCoin: LiveUserData.rCoin,
              diamond: LiveUserData.diamond,
              username: LiveUserData.username,
              isVIP: LiveUserData.isVIP,
              age: LiveUserData.age,
              audio: LiveUserData.audio,
              liveStreamingId: LiveUserData.liveStreamingId,
              view: String(0),
            },
            type: "LIVE",
          },
        };
        await fcm.send(payload, function (err, response) {
          if (err) {
            console.log("Something has gone wrong!", err);
          }
        });
      }
    } else {
      return res
        .status(200)
        .json({ status: false, message: "Invalid Details!" });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ status: false, error: error.message || "Server Error" });
  }
};

const LiveUserFunction = async (user, data) => {
  user.name = data.name;
  user.country = data.country;
  user.image = data.image;
  user.token = data.token;
  user.channel = data.channel;
  user.rCoin = data.rCoin;
  user.diamond = data.diamond;
  user.username = data.username;
  user.isVIP = data.isVIP;
  user.liveUserId = data._id;
  user.countryFlagImage = data.countryFlagImage;
  user.age = data.age;

  await user.save();
  return user;
};

// get live user list
exports.getLiveUser = async (req, res) => {
  try {
    if (!req.query.userId || !req.query.type) {
      return res
        .status(200)
        .json({ status: false, message: "Oops ! Invalid details." });
    }

    const [user, setting, fakeLiveUser] = await Promise.all([
      User.findOne({ _id: req.query.userId }),
      Setting.findOne({}).sort({ createdAt: -1 }),
      User.aggregate([
        {
          $match: {
            isFake: true,
            isBlock: false,
          },
        },
        {
          $project: {
            _id: 1,
            name: 1,
            country: 1,
            image: 1,
            link: 1,
            channel: 1,
            rCoin: 1,
            diamond: 1,
            username: 1,
            countryFlagImage: 1,
            isVIP: 1,
            age: 1,
            isFake: 1,
          },
        },
        {
          $addFields: {
            agoraUID: null,
            liveStreamingId: null,
            liveUserId: null,
            view: 0,
            token: null,
            seat: {
              $map: {
                input: seat.default,
                as: "seatItem",
                in: {
                  $mergeObjects: [
                    "$$seatItem",
                    {
                      userId: {
                        $cond: [
                          { $eq: ["$$seatItem.position", 0] },
                          "$_id",
                          "$$seatItem.userId",
                        ],
                      },
                      name: {
                        $cond: [
                          { $eq: ["$$seatItem.position", 0] },
                          "$name",
                          "$$seatItem.name",
                        ],
                      },
                      image: {
                        $cond: [
                          { $eq: ["$$seatItem.position", 0] },
                          "$image",
                          "$$seatItem.image",
                        ],
                      },
                      country: {
                        $cond: [
                          { $eq: ["$$seatItem.position", 0] },
                          "$country",
                          "$$seatItem.country",
                        ],
                      },
                    },
                  ],
                },
              },
            },
            background: null,
            audio: false,
          },
        },
        { $skip: req.query.start ? parseInt(req.query.start) : 0 }, // how many records you want to skip
        { $limit: req.query.limit ? parseInt(req.query.limit) : 20 },
      ]),
    ]);
    if (!user) {
      return res
        .status(200)
        .json({ status: false, message: "User does not Exist!" });
    }

    if (req.query.type === "All") {
      const users = await LiveUser.aggregate([
        {
          $match: {
            isPublic: true,
            liveUserId: { $ne: user._id },
          },
        },
        {
          $sort: { createdAt: -1 },
        },
        {
          $addFields: {
            View: {
              $size: {
                $filter: {
                  input: "$view",
                  as: "item",
                  cond: { $eq: ["$$item.isAdd", true] },
                },
              },
            },
          },
        },
        {
          $project: {
            _id: 1,
            liveUserId: 1,
            name: 1,
            country: 1,
            countryFlagImage: 1,
            image: 1,
            token: 1,
            channel: 1,
            rCoin: 1,
            diamond: 1,
            seat: 1,
            background: 1,
            audio: 1,
            username: 1,
            isVIP: 1,
            age: 1,
            liveStreamingId: 1,
            agoraUID: 1,
            view: "$View",
          },
        },
        {
          $addFields: {
            isFake: false,
            link: null,
          },
        },
        { $skip: req.query.start ? parseInt(req.query.start) : 0 }, // how many records you want to skip
        { $limit: req.query.limit ? parseInt(req.query.limit) : 20 },
      ]);

      if (setting.isFake) {
        return res.status(200).json({
          status: true,
          message: "Success",
          users: [...users, ...fakeLiveUser],
        });
      } else {
        return res.status(200).json({
          status: true,
          message: "Success",
          users: users,
        });
      }
    }

    if (req.query.type === "Popular") {
      const users = await LiveUser.aggregate([
        {
          $match: {
            isPublic: true,
          },
        },
        {
          $lookup: {
            from: "livestreaminghistories",
            let: { liveStreamingId: "$liveStreamingId" },
            as: "liveStreaming",
            pipeline: [
              {
                $match: { $expr: { $eq: ["$$liveStreamingId", "$_id"] } },
              },
            ],
          },
        },
        {
          $unwind: {
            path: "$liveStreaming",
            preserveNullAndEmptyArrays: false,
          },
        },
        {
          $addFields: {
            View: {
              $size: {
                $filter: {
                  input: "$view",
                  as: "item",
                  cond: { $eq: ["$$item.isAdd", true] },
                },
              },
            },
          },
        },
        {
          $project: {
            _id: 1,
            liveUserId: 1,
            name: 1,
            country: 1,
            image: 1,
            token: 1,
            channel: 1,
            countryFlagImage: 1,
            seat: 1,
            background: 1,
            audio: 1,
            rCoin: 1,
            diamond: 1,
            username: 1,
            isVIP: 1,
            age: 1,
            liveStreamingId: "$liveStreaming._id",
            gifts: "$liveStreaming.gifts",
            comments: "$liveStreaming.comments",
            view: "$View",
          },
        },
        {
          $addFields: {
            isFake: false,
            link: null,
          },
        },
        {
          $sort: { comments: -1, gifts: -1 },
        },
        { $skip: req.query.start ? parseInt(req.query.start) : 0 }, // how many records you want to skip
        { $limit: req.query.limit ? parseInt(req.query.limit) : 20 },
      ]);

      if (setting.isFake) {
        return res.status(200).json({
          status: true,
          message: "Success",
          users: [...users, ...fakeLiveUser],
        });
      } else {
        return res.status(200).json({
          status: true,
          message: "Success",
          users: users,
        });
      }
    }

    if (req.query.type === "Following") {
      const users = await LiveUser.aggregate([
        {
          $lookup: {
            from: "followers",
            let: { userId: "$liveUserId" },
            as: "follower",
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ["$$userId", "$toUserId"] },
                      { $eq: [user._id, "$fromUserId"] },
                    ],
                  },
                },
              },
            ],
          },
        },
        {
          $unwind: {
            path: "$follower",
            preserveNullAndEmptyArrays: false,
          },
        },
        {
          $addFields: {
            View: {
              $size: {
                $filter: {
                  input: "$view",
                  as: "item",
                  cond: { $eq: ["$$item.isAdd", true] },
                },
              },
            },
          },
        },
        {
          $project: {
            _id: 1,
            liveUserId: 1,
            name: 1,
            country: 1,
            image: 1,
            token: 1,
            channel: 1,
            rCoin: 1,
            seat: 1,
            countryFlagImage: 1,
            background: 1,
            audio: 1,
            diamond: 1,
            username: 1,
            isVIP: 1,
            age: 1,
            liveStreamingId: 1,
            view: "$View",
          },
        },
        {
          $addFields: {
            isFake: false,
            link: null,
          },
        },
        {
          $sort: { comments: -1, gifts: -1 },
        },
        { $skip: req.query.start ? parseInt(req.query.start) : 0 }, // how many records you want to skip
        { $limit: req.query.limit ? parseInt(req.query.limit) : 20 },
      ]);

      if (setting.isFake) {
        return res.status(200).json({
          status: true,
          message: "Success",
          users: [...users, ...fakeLiveUser],
        });
      } else {
        return res.status(200).json({
          status: true,
          message: "Success",
          users: users,
        });
      }
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      status: false,
      error: error.message || "Server Error",
      user: "",
    });
  }
};
